package poli.edu.co.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Controller {

	@FXML
	private Button botonA;

	@FXML
	private Button botonB;

	@FXML
	private Button botonBorrar;

	@FXML
	private Button botonC;

	@FXML
	private Button botonD;

	@FXML
	private Button botonE;

	@FXML
	private Button botonEnviar;

	@FXML
	private Button botonF;

	@FXML
	private Button botonG;

	@FXML
	private Button botonH;

	@FXML
	private Button botonI;

	@FXML
	private Button botonJ;

	@FXML
	private Button botonK;

	@FXML
	private Button botonL;

	@FXML
	private Button botonM;

	@FXML
	private Button botonN;

	@FXML
	private Button botonO;

	@FXML
	private Button botonP;

	@FXML
	private Button botonQ;

	@FXML
	private Button botonR;

	@FXML
	private Button botonS;

	@FXML
	private Button botonT;

	@FXML
	private Button botonU;

	@FXML
	private Button botonV;

	@FXML
	private Button botonW;

	@FXML
	private Button botonX;

	@FXML
	private Button botonY;

	@FXML
	private Button botonZ;

	@FXML
	private Button botonÑ;

	@FXML
	private TextField textfieldCasilla;
	
	private Boolean operationOn = true;

	@FXML
	void agregarLetra(ActionEvent event) {
		/*textfieldCasilla.setText(textfieldCasilla.getText()+ ((Button)event.getSource()).getText());
		operationOn = true;*/
	}

	@FXML
	void borrarLetra(ActionEvent event) {

		
	}

	@FXML
	void enviarPalabra(ActionEvent event) {

	}

	public void borrarLetra() {

	}

	public void enviarPalabra() {

	}

}
